package com.investorproducts.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.investorproducts.model.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {

}
