
package com.investorproducts.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.investorproducts.model.Investor;
import com.investorproducts.repository.InvestorReposity;


@Service
public class InvestorService {
	
	 @Autowired
	    private InvestorReposity investorRepository;
	    
	    @Autowired
	    private ProductService productService; // Assuming you need to link investors to products

	    /**
	     * Get a list of all investors.
	     *
	     * @return List of investors
	     */
	    public List<Investor> getAllInvestors() {
	        return investorRepository.findAll();
	    }

	    /**
	     * Get an investor by their ID.
	     *
	     * @param id Investor ID
	     * @return Investor or null if not found
	     */
	    public Investor getInvestorById(Long id) {
	        return investorRepository.findById(id).orElse(null);
	    }

	    /**
	     * Create a new investor.
	     *
	     * @param investor Investor to create
	     * @return Created investor
	     */
	    public Investor createInvestor(Investor investor) {

	    	 // Implement validation logic here if needed
	        // You can check if an investor with the same details already exists
	        return investorRepository.save(investor);
	    }

	    /**
	     * Update an existing investor.
	     *
	     * @param id             Investor ID to update
	     * @param updatedInvestor Updated investor data
	     * @return Updated investor or null if the investor doesn't exist
	     */
	    public Investor updateInvestor(Long id, Investor updatedInvestor) {
	        // Check if the investor exists
	        Investor existingInvestor = investorRepository.findById(id)
	                .orElse(null);

	        if (existingInvestor == null) {
	            throw new IllegalArgumentException("Investor not found");
	        }

	        // Implement update logic here, including validation if needed
	        // You can check if the updated details don't conflict with existing investors

	        // Update the investor's details
	        existingInvestor.setName(updatedInvestor.getName());
	        existingInvestor.setSurname(updatedInvestor.getSurname());
	        existingInvestor.setDateOfBirth(updatedInvestor.getDateOfBirth());
	        existingInvestor.setAddress(updatedInvestor.getAddress());
	        existingInvestor.setMobileNumber(updatedInvestor.getMobileNumber());
	        existingInvestor.setEmail(updatedInvestor.getEmail());

	        return investorRepository.save(existingInvestor);
	    }
	    /**
	     * Delete an investor by their ID.
	     *
	     * @param id Investor ID to delete
	     */
	    public void deleteInvestor(Long id) {
	        // Check if the investor exists
	        Investor existingInvestor = investorRepository.findById(id).orElse(null);

	        if (existingInvestor == null) {
	            throw new IllegalArgumentException("Investor not found");
	        }

	        // Implement delete logic here, including checking if the investor has any linked products
	        // If an investor has linked products, you may need to handle that relationship

	        investorRepository.deleteById(id);
	    }

	    // Additional Investor-related methods here
	}

