
package com.investorproducts.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.investorproducts.model.Product;
import com.investorproducts.service.ProductService;

import jakarta.persistence.EntityNotFoundException;


@RestController
@RequestMapping("/products")
public class ProductController {
	
	@Autowired
    private ProductService productService;

    /**
     * Get a list of all products.
     *
     * @return List of products
     */
    @GetMapping
    public List<Product> getAllProducts() {
        // You may add business logic here, e.g., filtering, sorting, or other operations
        return productService.getAllProducts();
    }

    /**
     * Get a product by its ID.
     *
     * @param id Product ID
     * @return Product or null if not found
     */
    @GetMapping("/{id}")
    public Product getProductById(@PathVariable Long id) {
        Product product = productService.getProductById(id);
        if (product == null) {
            // Handle the case when the product is not found
            throw new EntityNotFoundException("Product not found");
        }
        return product;
    }

    /**
     * Create a new product.
     *


}
    /**
     * Create a new product.
     *
     * @param product Product to create
     * @return Created product
     */
    @PostMapping
    public Product createProduct(@RequestBody Product product) {
        // You can implement validation logic here, e.g., checking for unique product names or other constraints
        return productService.createProduct(product);
    }

    /**
     * Update an existing product.
     *
     * @param id             Product ID to update
     * @param updatedProduct Updated product data
     * @return Updated product or null if the product doesn't exist
     */
    @PutMapping("/{id}")
    public Product updateProduct(@PathVariable Long id, @RequestBody Product updatedProduct) {
        Product updated = productService.updateProduct(id, updatedProduct);
        if (updated == null) {
            // Handle the case when the product is not found
            throw new EntityNotFoundException("Product not found");
        }
        return updated;
    }

    /**
     * Delete a product by its ID.
     *
     * @param id Product ID to delete
     */
    @DeleteMapping("/{id}")
    public void deleteProduct(@PathVariable Long id) {
        // Implement additional validation logic here, e.g., checking if the product is linked to any investors
        productService.deleteProduct(id);
    }

    // Additional Product-related methods here
}