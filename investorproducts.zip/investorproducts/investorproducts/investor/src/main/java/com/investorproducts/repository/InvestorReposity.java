package com.investorproducts.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.investorproducts.model.Investor;

public interface InvestorReposity extends JpaRepository<Investor, Long> {

}
