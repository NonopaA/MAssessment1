package com.investorproducts.swagger;

import org.springframework.context.annotation.Bean;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

public class SwagConfig {
	@Bean
	public Docket api() { //used to generate documentation for our API
		return new Docket(DocumentationType.SWAGGER_2).groupName("Investor_API")
		.select().apis(RequestHandlerSelectors.basePackage("com.investorproducts"
				+ ""))
		.paths(PathSelectors.any())
		.build();
	}
	
	
}


