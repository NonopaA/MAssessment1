package com.investorproducts.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.investorproducts.model.Withdrawal;

public interface WithdrawalRepository extends JpaRepository<Withdrawal, Long> {


}
