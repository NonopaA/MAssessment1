package com.investorproducts.model;


import java.math.BigDecimal;

import java.time.LocalDateTime;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="withdrawal_ddl")
public class Withdrawal {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private BigDecimal amount;
    private LocalDateTime withdrawalDate;
    
    // Add relationships to Investor and Product entities
    @ManyToOne
    private Investor investor;
    
    @ManyToOne
    private Product product;

	
    
     public Withdrawal() {
	
	}

	public Withdrawal(Long id, BigDecimal amount, LocalDateTime withdrawalDate, Investor investor, Product product) {
		
		this.id = id;
		this.amount = amount;
		this.withdrawalDate = withdrawalDate;
		this.investor = investor;
		this.product = product;
	}

	// Getters and setters
    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public LocalDateTime getWithdrawalDate() {
		return withdrawalDate;
	}

	public void setWithdrawalDate(LocalDateTime withdrawalDate) {
		this.withdrawalDate = withdrawalDate;
	}

	public Investor getInvestor() {
		return investor;
	}

	public void setInvestor(Investor investor) {
		this.investor = investor;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}


	public String toString() {
		return "Withdrawal [id=" + id + ", amount=" + amount + ", withdrawalDate=" + withdrawalDate + ", investor="
				+ investor + ", product=" + product + "]";
	}
    
    
   


}
