package com.investorproducts.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.investorproducts.model.Investor;
import com.investorproducts.service.InvestorService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import jakarta.persistence.EntityNotFoundException;

@RestController
@RequestMapping("/investors")
public class InvestorController {
	@Autowired
    private InvestorService investorService;
	
    /**
     * Get a list of all investors.
     *
     * @return List of investors
     */
    @GetMapping
    public List<Investor> getAllInvestors() {
        
        return investorService.getAllInvestors();
    }

    /**
     * Get an investor by their ID.
     *
     * @param id Investor ID
     * @return Investor or null if not found
     */
    @GetMapping("/{id}")
    public Investor getInvestorById(@PathVariable Long id) {
        Investor investor = investorService.getInvestorById(id);
        if (investor == null) {
            // Add error handling logic if the investor is not found
            throw new EntityNotFoundException("Investor not found");
        }
        return investor;
    }

    /**
     * Create a new investor.
     *


}
 /**
     * Create a new investor.
     *
     * @param investor Investor to create
     * @return Created investor
     */
    @PostMapping
    public Investor createInvestor(@RequestBody Investor investor) {
        // You can implement validation logic here, e.g., checking for unique email or other constraints
        return investorService.createInvestor(investor);
    }

    /**
     * Update an existing investor.
     *
     * @param id             Investor ID to update
     * @param updatedInvestor Updated investor data
     * @return Updated investor or null if the investor doesn't exist
     */
    @PutMapping("/{id}")
    public Investor updateInvestor(@PathVariable Long id, @RequestBody Investor updatedInvestor) {
        Investor updated = investorService.updateInvestor(id, updatedInvestor);
        if (updated == null) {
            // Handle the case when the investor is not found
            throw new EntityNotFoundException("Investor not found");
        }
        return updated;
    }

    /**
     * Delete an investor by their ID.
     *
     * @param id Investor ID to delete
 */
    @DeleteMapping("/{id}")
    public void deleteInvestor(@PathVariable Long id) {
        // Implement additional validation logic here, e.g., check if the investor has linked products
        investorService.deleteInvestor(id);
    }

    // Additional Investor-related methods here
}

