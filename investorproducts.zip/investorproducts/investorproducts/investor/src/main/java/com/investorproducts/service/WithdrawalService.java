package com.investorproducts.service;


import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.investorproducts.model.Investor;
import com.investorproducts.model.Product;
import com.investorproducts.model.Withdrawal;
import com.investorproducts.repository.InvestorReposity;
import com.investorproducts.repository.ProductRepository;
import com.investorproducts.repository.WithdrawalRepository;

import jakarta.persistence.EntityNotFoundException;


@Service
public class WithdrawalService {
	
	
	
	
	    @Autowired
	    private WithdrawalRepository withdrawalRepository;
	    
	    @Autowired
	    private ProductRepository productRepository;

	    @Autowired
	    private InvestorReposity investorRepository;

	    
	    
	    public List<Withdrawal> getAllWithdrawals() {
	        return withdrawalRepository.findAll();
	    }

	    /**
	     * Retrieves a withdrawal by its ID.
	     *
	     * @param withdrawalId The ID of the withdrawal to retrieve.
	     * @return The withdrawal entity if found.
	     * @throws EntityNotFoundException if the withdrawal is not found.
	     */
	    public Withdrawal getWithdrawalById(Long id) {
	        return withdrawalRepository.findById(id)
	                .orElseThrow(() -> new EntityNotFoundException("Withdrawal not found"));
	    }
	    
	     /**
	     * Creates a new withdrawal and performs necessary validations.
	     *
	     * withdrawal The withdrawal to be created.
	     * The created withdrawal entity if validations pass.
	     */
	    public Withdrawal createWithdrawal(Withdrawal withdrawal) {
	        // Retrieve the associated product
	        Product product = productRepository.findById(withdrawal.getProduct().getId())
	                .orElseThrow(() -> new EntityNotFoundException("Product not found"));

	        // Perform withdrawal validations
	        if (product.getType().equals("RETIREMENT")) {
	            // Check investor's age for RETIREMENT product
	            if (isInvestorEligibleForRetirementWithdrawal(withdrawal.getInvestor())) {
	                // Check withdrawal amount
	                if (withdrawal.getAmount().compareTo(product.getBalance()) <= 0) {
	                    // Check if withdrawal amount is not more than 90% of the current balance
	                    BigDecimal maxWithdrawalAmount = product.getBalance().multiply(BigDecimal.valueOf(0.9));
	                    if (withdrawal.getAmount().compareTo(maxWithdrawalAmount) <= 0) {
	                        withdrawal.setWithdrawalDate(LocalDateTime.now());
	                        return withdrawalRepository.save(withdrawal);
	                    } else {
	                        throw new ValidationException("Withdrawal amount exceeds 90% of current balance");
	                    }
	                } else {
	                    throw new ValidationException("Withdrawal amount is greater than current balance");
	                }
	            } else {
	                throw new ValidationException("Investor is not eligible for RETIREMENT withdrawal");
	            }
	        } else {
	            // For SAVINGS product, there are no additional validations
	            withdrawal.setWithdrawalDate(LocalDateTime.now());
	            return withdrawalRepository.save(withdrawal);
	        }
	    }

	    /**
	     * Checks if an investor is eligible for a RETIREMENT withdrawal based on age.
	     *
	     * @param investor The investor entity.
	     * @return true if the investor is eligible, false otherwise.
	     */
	    private boolean isInvestorEligibleForRetirementWithdrawal(Investor investor) {
	        // Retrieve the investor's birthdate from the database
	        LocalDate birthDate = investorRepository.findById(investor.getId())
	                .orElseThrow(() -> new EntityNotFoundException("Investor not found"))
	                .getDateOfBirth();

	        LocalDate currentDate = LocalDate.now();
	        long age = Period.between(birthDate, currentDate).getYears();
	        
	        return age > 65;
	    }

	    /**
	     * Updates an existing withdrawal.
	     *
	     * @param withdrawalId The ID of the withdrawal to update.
	     * @param updatedWithdrawal The updated withdrawal entity.
	     * @return The updated withdrawal entity.
	     * @throws EntityNotFoundException if the withdrawal is not found.
	     */
	    public Withdrawal updateWithdrawal(Long withdrawalId, Withdrawal updatedWithdrawal) {
	        if (withdrawalRepository.existsById(withdrawalId)) {
	            updatedWithdrawal.setId(withdrawalId);
	            return withdrawalRepository.save(updatedWithdrawal);
	        } else {
	            throw new EntityNotFoundException("Withdrawal not found");
	        }
	    }

	    /**
	     * Deletes a withdrawal by its ID.
	     *
	     * @param withdrawalId The ID of the withdrawal to delete.
	     * @throws EntityNotFoundException if the withdrawal is not found.
	     */
	    public void deleteWithdrawal(Long withdrawalId) {
	        if (withdrawalRepository.existsById(withdrawalId)) {
	            withdrawalRepository.deleteById(withdrawalId);
	        } else {
	            throw new EntityNotFoundException("Withdrawal not found");
	        }
	    }
	    // Other methods for retrieving withdrawal history, etc.
	    
	    // Add comments for other methods as needed
	}



