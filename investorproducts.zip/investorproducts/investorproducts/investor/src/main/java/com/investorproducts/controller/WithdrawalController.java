package com.investorproducts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.investorproducts.model.Withdrawal;
import com.investorproducts.service.WithdrawalService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.persistence.EntityNotFoundException;

@RestController
@RequestMapping("/withdrawals")
public class WithdrawalController {
	
	
	    @Autowired
	    private WithdrawalService withdrawalService;

	    /**
	     * Create a new withdrawal.
	     *
	     * @param withdrawal The withdrawal request to be created.
	     * @return The created withdrawal if successful.
	     */
	    @PostMapping
	    public ResponseEntity<Withdrawal> createWithdrawal(@RequestBody Withdrawal withdrawal) {
	        Withdrawal createdWithdrawal = withdrawalService.createWithdrawal(withdrawal);
	        return new ResponseEntity<>(createdWithdrawal, HttpStatus.CREATED);
	    }

	    /**
	     * Get a list of all withdrawals.
	     *
	     * @return List of all withdrawal records.
	     */
	    @GetMapping
	    public ResponseEntity<List<Withdrawal>> getAllWithdrawals() {
	        List<Withdrawal> withdrawals = withdrawalService.getAllWithdrawals();
	        return new ResponseEntity<>(withdrawals, HttpStatus.OK);
	    }

	    /**
	     * Get a withdrawal by its ID.
	     *
	     * @param withdrawalId The ID of the withdrawal to retrieve.
	     * @return The withdrawal entity if found.
	     * @throws EntityNotFoundException if the withdrawal is not found.
	     */
	    @GetMapping("/{withdrawalId}")
	    public ResponseEntity<Withdrawal> getWithdrawalById(@PathVariable Long id) {
	        Withdrawal withdrawal = withdrawalService.getWithdrawalById(id);
	        return new ResponseEntity<>(withdrawal, HttpStatus.OK);
	    }

	    /**;
	     * Update an existing withdrawal.
	     *
	     * @param withdrawalId       The ID of the withdrawal to update.
	     * @param updatedWithdrawal The updated withdrawal request.
	     * @return The updated withdrawal if successful.
	     */
	    @PutMapping("/{withdrawalId}")
	    public ResponseEntity<Withdrawal> updateWithdrawal(@PathVariable Long withdrawalId, @RequestBody Withdrawal updatedWithdrawal) {
	        Withdrawal updated = withdrawalService.updateWithdrawal(withdrawalId, updatedWithdrawal);
	        return new ResponseEntity<>(updated, HttpStatus.OK);
	    }

	    /**
	     * Delete a withdrawal by its ID.
	     *
	     * @param withdrawalId The ID of the withdrawal to delete.
	     * @return HTTP status indicating the result.
	     */
	    @DeleteMapping("/{withdrawalId}")
	    public ResponseEntity<Void> deleteWithdrawal(@PathVariable Long withdrawalId) {
	        withdrawalService.deleteWithdrawal(withdrawalId);
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	    }
	}



