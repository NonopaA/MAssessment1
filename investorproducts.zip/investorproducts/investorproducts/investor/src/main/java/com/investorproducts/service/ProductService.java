package com.investorproducts.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.investorproducts.model.Product;
import com.investorproducts.repository.ProductRepository;

@Service
public class ProductService {
	
	
    @Autowired
    private ProductRepository productRepository;

    /**
     * Get a list of all products.
     *
     * @return List of products
     */
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    /**
     * Get a product by its ID.
     *
     * @param id Product ID
     * @return Product or null if not found
     */
    public Product getProductById(Long id) {
        return productRepository.findById(id).orElse(null);
    }

    /**
     * Create a new product.
     *
     * @param product Product to create
     * @return Created product
     */
    public Product createProduct(Product product) {
        // Implement validation logic here if needed
        // You can check if a product with the same details already exists
        return productRepository.save(product);
    }
    /**
     * Update an existing product.
     *
     * @param id             Product ID to update
     * @param updatedProduct Updated product data
     * @return Updated product or null if the product doesn't exist
     */
    public Product updateProduct(Long id, Product updatedProduct) {
        // Check if the product exists
        Product existingProduct = productRepository.findById(id).orElse(null);

        if (existingProduct == null) {
            throw new IllegalArgumentException("Product not found");
        }

        // Implement update logic here, including validation if needed
        // You can check if the updated details don't conflict with existing products

        // Update the product's details
        existingProduct.setType(updatedProduct.getType());
        existingProduct.setName(updatedProduct.getName());
        existingProduct.setBalance(updatedProduct.getBalance());

        return productRepository.save(existingProduct);
    }

    /**
     * Delete a product by its ID.
     *
     * @param id Product ID to delete
     */
    public void deleteProduct(Long id) {
        // Check if the product exists
        Product existingProduct = productRepository.findById(id) .orElse(null);

        if (existingProduct == null) {
            throw new IllegalArgumentException("Product not found");
        }

    }

}
