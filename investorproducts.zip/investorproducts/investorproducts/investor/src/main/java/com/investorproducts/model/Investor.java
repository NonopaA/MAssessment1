package com.investorproducts.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;


import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "investor_ddl")
public class Investor {
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    private String name;
	    private String surname;
	    private LocalDate dateOfBirth;
	    private String address;
	    private String mobileNumber;
	    private String email;
		
	    
	    
    public Investor() {
	
		}
		public Investor(Long id, String name, String surname, LocalDate dateOfBirth, String address,
				String mobileNumber, String email) {
			
			this.id = id;
			this.name = name;
			this.surname = surname;
			this.dateOfBirth = dateOfBirth;
			this.address = address;
			this.mobileNumber = mobileNumber;
			this.email = email;
		}
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getSurname() {
			return surname;
		}
		public void setSurname(String surname) {
			this.surname = surname;
		}
		public LocalDate getDateOfBirth() {
			return dateOfBirth;
		}
		public void setDateOfBirth(LocalDate dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getMobileNumber() {
			return mobileNumber;
		}
		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}



	public String toString() {
		return "Investor{" +
				"id=" + id +
				", name='" + name + '\'' +
				", surname='" + surname + '\'' +
				", dateOfBirth=" + dateOfBirth +
				", address='" + address + '\'' +
				", mobileNumber='" + mobileNumber + '\'' +
				", email='" + email + '\'' +
				'}';
	}
}

