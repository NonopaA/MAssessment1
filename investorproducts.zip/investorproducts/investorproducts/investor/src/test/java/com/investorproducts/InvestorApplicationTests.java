package com.investorproducts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvestorApplicationTests {

	@Test
	void contextLoads() {
	}

}
